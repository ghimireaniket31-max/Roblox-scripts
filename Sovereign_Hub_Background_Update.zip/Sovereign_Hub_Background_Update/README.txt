SOVEREIGN HUB — BACKGROUND UPDATE

Included:
- Sovereign_Hub_Advanced_V3.lua (updated UI script)
- Sovereign_Hub_Red_Crown_Background.png (new black/red crown background)

The updated script is still a client-side UI preview. It does not add game automation,
teleporting, remote calls, or exploit actions.

IMPORTANT — ROBLOX IMAGE SETUP
Roblox UI cannot display a local PNG file directly from this ZIP. First upload
Sovereign_Hub_Red_Crown_Background.png as an image/decal to Roblox and copy its
numeric asset ID. Then:
1. Run the UI in your own Roblox Studio experience as a LocalScript.
2. Open the Settings tab.
3. Paste the numeric image asset ID into “Background image asset ID”.
4. Press “APPLY ASSETS”.

You can also set the ID before running by changing ASSETS.Background = 0 near
the top of the Lua file to ASSETS.Background = YOUR_NUMERIC_ASSET_ID.

The background is cropped to fill the UI and darkened slightly for readability.
